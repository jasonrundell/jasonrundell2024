# jasonrundell2024


npx cross-env CONTENTFUL_SPACE_ID=YOUR_SPACE_ID CONTENTFUL_ACCESS_TOKEN=XXX npm run setup