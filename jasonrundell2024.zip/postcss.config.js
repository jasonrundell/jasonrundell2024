module.exports = {
  plugins: {
    'postcss-normalize': {},
    autoprefixer: {},
  },
}
